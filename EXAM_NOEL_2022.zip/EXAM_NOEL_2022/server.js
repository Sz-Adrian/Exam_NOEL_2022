const { response, request } = require("express");
let express = require("express");

let app = express();
var port = process.env.PORT || 8000;
var util = require("util");
var http = require("http");

var cookieParser = require('cookie-parser');
app.use(cookieParser())

 app.get('/cookie',function(req,res){
    res.cookie("cookie_name","my_cookie_value").send("cooki set");
});

app.get('/clearcookie',function(req,res){
    res.clearCookie("cookie_name");
    res.send("Cook delete");
}); 


var mysql=require("mysql2");
var connection = mysql.createConnection({
    host    : '127.0.0.1',
    user    :'root',
    password: 'Adriancom0906',
    database: 'users'
});
connection.connect(function(error){ if (error) console.log(error);});

app.use(express.urlencoded({extended : true}));


    //________________ROUTE____________________

 app.get('/',(request,response) => {
    //response.send("Hiooooooo, Momooooo \n <h1> J'ai fait un site internet</h1>");
    response.render('home.ejs');
});


app.get('/user',(request,response) => {
    connection.query("select * from user;", function(error,result){
        if(error) console(error);
        response.render('encode.ejs',{users: result});
    });
    
});

app.post('/user',(request,response) => {
    let user = {"lastname":request.body.destination,"firstname":request.body.places}
    connection.query("INSERT INTO user SET ? ",user,  function(error,result){
        if(error) {
            console.log(error);
        }
        else{
        response.redirect('/user');
        }
    });
});

app.post('/user/valid',(request,response) => {
    response.redirect('/user/valid');
});

app.get('/user/valid',(request,response) => {
    connection.query("select * from user;", function(error,result){
        if(error) console(error);
        response.render('validation.ejs',{users: result});
    });
});

app.post('/confirmation',(request,response) => {
    response.redirect('/confirmation');
});

app.get('/confirmation',(request,response) => {
    
        response.render('confirmation.ejs');
    
    
});



app.get('/user/add',(request,response) => {
    connection.query("select * from user;", function(error,result){
        if(error) console(error);
        response.render('Reservation.ejs',{users: result});
    });
    
});

app.get('/user/update/:i',(request,response) => {
    let i = request.params.i;
    connection.query("select * from user Where iduser = ?;",i, function(error,result){
        if(error) console(error);
        response.render('userUpdate.ejs',{"iduser": result[0].iduser,"lastname":result[0].lastname,"firstname":result[0].firstname});
    });
});

app.post('/user/update',(request,response) => {
    let i = request.body.iduser;
    let user = {"lastname":request.body.lastname,"firstname":request.body.firstname}
    connection.query("UPDATE user SET ? WHERE iduser = ?",[user,i], function(error,result){
        if(error) console(error);
        response.redirect('/user');
    });
});



//Delete

app.get('/user/delete/:i',(require,response) => {
    let i = require.params.i;
    connection.query("DELETE from user WHERE iduser = ?;",i, function(error,result) {
        if(error) {
            console.log(error);
        }
        else{
            response.redirect("/user");
        }
    });
    
});


app.post('/',(request,response) => {
    console.log(request.body);
    response.send("Hiooooo  "+request.body.nom);
});



    //________________URL____________________

app.get("/index",(request,response) => {
    response.send('Bonjour eee ' + request.query.name);
});


//________________PARAM____________________

app.get("/index/:name",(request,response) => {
    //response.send('Bonjour ' + request.params.name);
    response.render('home.ejs',{name: request.params.name});
}); 

//________________utiliser le dossier public____________________

app.use(express.static('public'));

/* const bouton = document.getElementById("button")
bouton.addEventListener('click', function() 
{
    let elem2 = document.getElementById('tx')
    elem2.innerHTML = "Flouuuur"
}) */
/* let routes =require('./route');
app.use('/',routes); 
let total = require('./Total');

app.use('/',total);*/
app.listen(port,function(){
    console.log("Server is running on 8000");
});