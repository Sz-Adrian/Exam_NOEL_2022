let express =require('express');
let router = express.Router();

router.get('/cookie',function(req,res){
    res.cookie("cookie_name","my_cookie_value").send("cooki set");
});

router.get('/',(req,res) => {
    console.log("Cook : " ,req.cookies);
    res.send("Cookie value : "+req.cookies.cookie_name)
});

router.get('/clearcookie',function(req,res){
    res.clearCookie("cookie_name");
    res.send("Cook delete");
});

router.get('/',(request,response) => {
    //response.send("Hiooooooo, Momooooo \n <h1> J'ai fait un site internet</h1>");
    response.render('home.ejs');
});


router.get('/user',(request,response) => {
    connection.query("select * from user;", function(error,result){
        if(error) console(error);
        response.render('userList.ejs',{users: result});
    });
    
});

router.post('/user',(request,response) => {
    let user = {"lastname":request.body.lastname,"firstname":request.body.firstname}
    connection.query("INSERT INTO user SET ? ",user,  function(error,result){
        if(error) {
            console.log(error);
        }
        else{
        response.redirect('/user');
        }
    });
});

router.get('/user/add',(request,response) => {
    connection.query("select * from user;", function(error,result){
        if(error) console(error);
        response.render('userAdd.ejs',{users: result});
    });
    
});

router.get('/user/update/:i',(request,response) => {
    let i = request.params.i;
    connection.query("select * from user Where iduser = ?;",i, function(error,result){
        if(error) console(error);
        response.render('userUpdate.ejs',{"iduser": result[0].iduser,"lastname":result[0].lastname,"firstname":result[0].firstname});
    });
});

router.post('/user/update',(request,response) => {
    let i = request.body.iduser;
    let user = {"lastname":request.body.lastname,"firstname":request.body.firstname}
    connection.query("UPDATE user SET ? WHERE iduser = ?",[user,i], function(error,result){
        if(error) console(error);
        response.redirect('/user');
    });
});


//Delete

router.get('/user/delete/:i',(require,response) => {
    let i = require.params.i;
    connection.query("DELETE from user WHERE iduser = ?;",i, function(error,result) {
        if(error) {
            console.log(error);
        }
        else{
            response.redirect("/user");
        }
    });
    
});


router.post('/',(request,response) => {
    console.log(request.body);
    response.send("Hiooooo  "+request.body.nom);
});



    //________________URL____________________

router.get("/index",(request,response) => {
    response.send('Bonjour eee ' + request.query.name);
});


//________________PARAM____________________

router.get("/index/:name",(request,response) => {
    //response.send('Bonjour ' + request.params.name);
    response.render('home.ejs',{name: request.params.name});
});

module.exports = router;