class Reservation {
    constructor(dest, places, assurance){
        this.dest = dest;
        this.places = places;
        this.assurance = assurance;
        let numéro = 1;
    }
}



/* function show(){
    let Total = 0
    let assurance = document.getElementById("assurance").value
    
    let plc = document.getElementById("Places").value
    
    if(assurance == True){
        Total += 20;
    }
    Total+= plc;
    let elem = document.getElementById('total')
    elem.innerHTML = "Salut"+Total+"";
}

show()
*/
const bouton = document.getElementById("button")
bouton.addEventListener('click', function() 
{
    console.log("DAFA");
})  